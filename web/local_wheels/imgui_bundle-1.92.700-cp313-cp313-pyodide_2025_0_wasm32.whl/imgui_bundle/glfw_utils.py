# Part of ImGui Bundle - MIT License - Copyright (c) 2022-2026 Pascal Thomet - https://github.com/pthom/imgui_bundle
from typing import cast

try:
    import glfw  # pip install glfw


    def glfw_window_hello_imgui() -> glfw._GLFWwindow:
        """Return the main glfw window used by HelloImGui (when the backend is GLFW)
        You can use this window to set up additional GLFW callbacks.
        """
        import ctypes
        from imgui_bundle import hello_imgui

        window_address = hello_imgui.get_glfw_window_address()
        window_pointer = ctypes.cast(window_address, ctypes.POINTER(glfw._GLFWwindow))
        return cast(glfw._GLFWwindow, window_pointer)


except (ImportError, ModuleNotFoundError):


    def glfw_window_hello_imgui() -> None:  # type: ignore
        import sys
        print("""Please install glfw, so that glfw_window_hello_imgui works:
        pip install glfw""")
        sys.exit(1)


    pass
    # print("Warning: could not import glfw")
